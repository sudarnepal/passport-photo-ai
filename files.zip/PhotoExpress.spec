# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec file for Photo Express Cary
# Run with: pyinstaller PhotoExpress.spec

import sys
from pathlib import Path

block_cipher = None

# Collect all necessary data files
added_files = [
    ("app.py", "."),
]

a = Analysis(
    ["launcher.py"],
    pathex=[],
    binaries=[],
    datas=added_files,
    hiddenimports=[
        # Streamlit internals
        "streamlit",
        "streamlit.web",
        "streamlit.web.cli",
        "streamlit.runtime",
        "streamlit.runtime.scriptrunner",
        "streamlit.components.v1",
        # Image processing
        "PIL",
        "PIL.Image",
        "PIL.ImageDraw",
        "cv2",
        "numpy",
        # Face detection
        "mediapipe",
        "mediapipe.python.solutions",
        "mediapipe.python.solutions.face_detection",
        # RAW support
        "rawpy",
        # Background removal
        "rembg",
        # PDF / metadata
        "reportlab",
        "piexif",
        # Other
        "altair",
        "click",
        "packaging",
        "importlib_metadata",
        "typing_extensions",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="PhotoExpress",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,   # No black terminal window
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,        # Add .ico file path here if you have one
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="PhotoExpress",
)
